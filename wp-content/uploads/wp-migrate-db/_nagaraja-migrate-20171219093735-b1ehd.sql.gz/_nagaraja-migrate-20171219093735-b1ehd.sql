# WordPress MySQL database migration
#
# Generated: Tuesday 19. December 2017 09:37 UTC
# Hostname: localhost
# Database: `_nagaraja`
# URL: //projects.razorbee.com/nagaraja
# Path: /home/moktarul/public_html/projects.razorbee.com/nagaraja
# Tables: wp_commentmeta, wp_comments, wp_expm_maker, wp_expm_maker_pages, wp_links, wp_options, wp_postmeta, wp_posts, wp_revslider_css, wp_revslider_layer_animations, wp_revslider_navigations, wp_revslider_sliders, wp_revslider_slides, wp_revslider_static_slides, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wonderplugin_carousel
# Table Prefix: wp_
# Post Types: revision, attachment, carousels, mc4wp-form, nav_menu_item, page, post, tt-event, tt-issue, tt-member, tt-reformation, tt-story, wpcf7_contact_form
# Protocol: http
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

